package be.bxl.formation;

public class tabledemultiplicationDeux
{
    public static void main(String[] args)
{
    int incr =0;
    while(incr<=10) {
        System.out.println(incr +" x 2 =" + (incr *2) );
        incr++;


    }




}

}
