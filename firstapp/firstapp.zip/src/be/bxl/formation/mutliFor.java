package be.bxl.formation;

public class mutliFor {
    public static void main(String[] args) {

        for (int j=2; j<=10; j++ ) {
            System.out.println();
            for (int i=0; i<=10;i++ ) {
                System.out.println(i + " x " + j + "=" + (i * j));
            }


        }


    }
}